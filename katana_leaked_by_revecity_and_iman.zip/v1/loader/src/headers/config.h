#pragma once

#define HTTP_SERVER "198.251.81.249"
#define HTTP_PORT 80

#define TFTP_SERVER "198.251.81.249"
