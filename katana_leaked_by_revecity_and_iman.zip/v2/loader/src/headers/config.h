#pragma once

#define HTTP_SERVER "37.46.150.229"
#define HTTP_PORT 80

#define TFTP_SERVER "37.46.150.229"
