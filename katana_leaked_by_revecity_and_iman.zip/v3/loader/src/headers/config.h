#pragma once

#define HTTP_SERVER "11.11.11.11"
#define HTTP_PORT 80

#define TFTP_SERVER "11.11.11.11"
