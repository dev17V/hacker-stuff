package me.aaronakhtar.jbot.objects;

public enum ConnectionType {

    BOT, CLIENT

}
